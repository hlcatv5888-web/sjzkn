"""Android API 等价桩（纯 Python 侧）
   分工说明：
   - ActivityThread 反射（mActivities/paused/activity）已在【真 JVM】上用 stubsrc/*.java + Driver 证明成立；
   - 这里只桩控件/Builder 链，用来验证我们代码的接线：Builder 调用序、holder 时序、post 异步语义、
     _pending/flush、复制回调、异常拦截、降级分支。
   - Chaquopy 的 dynamic_proxy 本身是平台能力（要求 super().__init__()），此处用等价基类模拟其契约。
   - post() 只入队不执行 = 模拟真实 UI 线程异步。"""
import sys, types

EVENTS = []          # 记录 UI 线程上真实发生的动作，供断言
SUPER_CALLED = []


# ---------------------------------------------------------------- android 控件桩
class _View(object):
    def getClass(self):
        return _JClass(type(self))

    def __init__(self, ctx=None):
        self.ctx = ctx
        self.pad = (0, 0, 0, 0)
        self._pending = []
        self.postCount = 0
        self.children = []

    def setPadding(self, l, t, r, b):
        self.pad = (l, t, r, b)

    def addView(self, v, params=None):
        self.children.append(v)
        self.params = params
        return self

    def post(self, r):
        self.postCount += 1
        self._pending.append(r)          # 异步：排队，不立刻跑
        return True

    def drain(self):
        n = 0
        while self._pending:
            self._pending.pop(0).run()   # 模拟 UI 线程
            n += 1
        return n


class _ViewGroup(_View):
    HORIZONTAL, VERTICAL = 0, 1
    LayoutParams = None                  # 由下面 LinearLayout 覆盖

    def setOrientation(self, o):
        self.orientation = o


class _LinearLayout(_ViewGroup):
    class LayoutParams(object):
        def __init__(self, w, h):
            self.width, self.height = w, h


class _ScrollView(_ViewGroup):
    pass


class _TextView(_View):
    def __init__(self, ctx=None):
        _View.__init__(self, ctx)
        self.text = ""
        self.size = 0.0
        self.selectable = False

    def setText(self, t):
        self.text = t
        EVENTS.append(("setText", str(t)[-24:]))

    def getText(self):
        return self.text

    def setTextSize(self, s):
        self.size = s

    def setTextIsSelectable(self, b):
        self.selectable = b


class _Builder(object):
    last = None

    def __init__(self, ctx):
        self.ctx = ctx
        self.title = None
        self.view = None
        self.neutral = None
        self.negative = None

    def setTitle(self, t):
        self.title = t
        return self

    def setView(self, v):
        self.view = v
        return self

    def setNeutralButton(self, t, l):
        self.neutral = l
        return self

    def setNegativeButton(self, t, l):
        self.negative = l
        return self

    def show(self):
        d = _AlertDialog()
        d.title, d.view, d.neutral, d.negative, d.shown = (
            self.title, self.view, self.neutral, self.negative, True)
        _Builder.last = d
        EVENTS.append(("show", str(self.title)))
        return d


class _AlertDialog(object):
    pass


class _Toast(object):
    def __init__(self, msg, dur):
        self.msg, self.dur, self.shown = msg, dur, False

    @staticmethod
    def makeText(ctx, msg, dur):
        return _Toast(msg, dur)

    def show(self):
        self.shown = True
        EVENTS.append(("toast", str(self.msg)))


class _ClipData(object):
    def __init__(self, label, text):
        self.label, self.text = label, text

    @staticmethod
    def newPlainText(label, text):
        return _ClipData(label, text)


class _Context(object):
    def getSystemService(self, name):
        return _Clipboard()


class _Clipboard(object):
    def __init__(self):
        self.clip = None

    def setPrimaryClip(self, c):
        self.clip = c
        EVENTS.append(("clip", str(c.text)[-20:]))


class _Window(object):
    def __init__(self):
        self.decorView = _View()

    def getDecorView(self):
        return self.decorView


class _Activity(_Context):
    def __init__(self):
        self.window = _Window()

    def getWindow(self):
        return self.window


class _ActivityClientRecord(object):
    def getClass(self):
        return _JClass(type(self))

    def __init__(self, activity, paused):
        self.activity, self.paused = activity, paused


class _JMethod(object):
    def __init__(self, owner, name):
        self.owner, self.name = owner, name

    def invoke(self, inst, *a):
        return getattr(self.owner, self.name)()


class _JField(object):
    def __init__(self, owner, name):
        self.owner, self.name, self.acc = owner, name, False

    def setAccessible(self, b):
        self.acc = b
        return self

    def get(self, obj):
        return getattr(obj, self.name)

    def getBoolean(self, obj):
        return bool(getattr(obj, self.name))


class _JClass(object):
    """仿 java.lang.Class：只实现我们代码用到的那几个成员"""
    def __init__(self, cls):
        self.cls = cls

    @staticmethod
    def forName(name):
        return _JClass(_TABLE[name])

    def getMethod(self, name):
        return _JMethod(self.cls, name)

    def getDeclaredField(self, name):
        return _JField(self.cls, name)


class _HashMap(object):
    """仿 java.util.Map：values().toArray() 是 _activity() 反射写法必需的一环"""
    def __init__(self):
        self._d = {}

    def put(self, k, v):
        self._d[k] = v
        return v

    def get(self, k):
        return self._d.get(k)

    def size(self):
        return len(self._d)

    def values(self):
        outer = self

        class _V(object):
            def toArray(self):
                return list(outer._d.values())
        return _V()


class _ActivityThread(object):
    current = None

    def __init__(self):
        self.mActivities = _HashMap()

    @staticmethod
    def currentActivityThread():
        return _ActivityThread.current

    @staticmethod
    def install(t):
        _ActivityThread.current = t


_TABLE = {
    "android.app.AlertDialog$Builder": _Builder,
    "android.app.AlertDialog": _AlertDialog,
    "android.widget.TextView": _TextView,
    "android.widget.ScrollView": _ScrollView,
    "android.widget.LinearLayout": _LinearLayout,
    "android.widget.LinearLayout$LayoutParams": _LinearLayout.LayoutParams,
    "android.content.DialogInterface$OnClickListener": object,
    "android.widget.Toast": _Toast,
    "android.content.ClipData": _ClipData,
    "android.app.Activity": _Activity,
    "android.app.ActivityThread": _ActivityThread,
    "android.app.ActivityThread$ActivityClientRecord": _ActivityClientRecord,
    "java.lang.Class": _JClass,
}


_ActivityThread.ActivityClientRecord = _ActivityClientRecord   # 模拟 Java 嵌套类访问
_AlertDialog.Builder = _Builder


def jclass(name):
    return _TABLE[name]


def dynamic_proxy(jcls):
    class _Base(object):
        def __init__(self, *a, **kw):
            SUPER_CALLED.append(getattr(self, "fn", None) is not None)
    return _Base


def install():
    m = types.ModuleType("java")
    m.jclass = jclass
    m.dynamic_proxy = dynamic_proxy
    m.lang = types.ModuleType("java.lang")
    m.lang.Runnable = object
    sys.modules["java"] = m
    sys.modules["java.lang"] = m.lang
    return m


def pump(act):
    return act.getWindow().getDecorView().drain()
