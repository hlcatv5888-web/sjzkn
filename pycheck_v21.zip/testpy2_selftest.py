import sys, os, json, time, importlib.util
H = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(H, "sb2"))
sys.path.insert(0, H)
def load(p, n="t"):
    s = importlib.util.spec_from_file_location(n, p); m = importlib.util.module_from_spec(s)
    sys.modules[n] = m; s.loader.exec_module(m); return m
t = load(os.path.join(H, "testpy2.py"), "t2")
D = os.path.join(H, "sb2")
NG = []
def chk(name, cond, extra=""):
    print(("  OK  " if cond else "  NG  ") + name + ("  " + str(extra) if extra else ""))
    if not cond: NG.append(name)

sp = t.Spider()
sp.init(json.dumps({"dir": D, "timeout": 6, "workers": 3}))

# 契约
chk("getDependence 存在且为空", sp.getDependence() == [])
chk("isVideoFormat", sp.isVideoFormat("http://a/b.m3u8") is True and sp.isVideoFormat("http://a/b.html") is False)
chk("homeContent 形状", isinstance(sp.homeContent(True).get("class"), list))
c = sp.categoryContent("test", "1", False, {})
chk("分类返回契约", all(k in c for k in ("page","pagecount","limit","total","list")))
chk("action 卡片带 action 字段", c["list"][0].get("action") == t.CMD_RUN)
s = sp.searchContent("good", False, "1")
chk("搜索契约", all(k in s for k in ("list","page","pagecount","limit","total")))

# 批量（走真实 _run_batch 路径，含并发+导出）
r = sp.action(t.CMD_RUN)
chk("action 返回 json", isinstance(json.loads(r), dict))
for _ in range(80):
    if not t._STATE["run"]: break
    time.sleep(0.5)
res = t._all(t._STATE)
byname = {os.path.basename(k): v for k, v in res.items()}
print("\n-- 各样本判定 --")
for k in sorted(byname): print("  %-18s %-5s %s" % (k, byname[k]["status"], byname[k]["msg"][:80]))
print()
chk("good=ok", byname["good.py"]["status"] == "ok")
chk("good 有分类数与契约", byname["good.py"]["detail"].get("cnt") == 20 and byname["good.py"]["detail"].get("contract","").startswith("✅"))
chk("syntaxerr=fail 且有堆栈", byname["syntaxerr.py"]["status"] == "fail" and "SyntaxError" in byname["syntaxerr.py"]["detail"].get("trace",""))
chk("noclass=fail", byname["noclass.py"]["status"] == "fail" and "未找到爬虫类" in byname["noclass.py"]["msg"])
chk("hang=fail 超时且指明阶段", byname["hang.py"]["status"] == "fail" and "超时" in byname["hang.py"]["msg"])
chk("neterr=warn 网络", byname["neterr.py"]["status"] == "warn" and "网络" in byname["neterr.py"]["msg"])
chk("logicerr=warn 契约异常降级", byname["logicerr.py"]["status"] == "warn" and "契约" in byname["logicerr.py"]["msg"])
chk("noclass_home=warn 无分类", byname["noclass_home.py"]["status"] == "warn" and "class" in byname["noclass_home.py"]["msg"])
chk("bare 被鸭子类型找到且报依赖", byname["bare.py"]["detail"].get("deps") == "requests" and byname["bare.py"]["status"]=="ok")
chk("报告已导出", os.path.isfile(os.path.join(D, "pycheck_report.txt")))
chk("无残留 sys.modules", not [k for k in sys.modules if k.startswith("pyscan_")])
chk("sys.path 已还原", not any(os.path.abspath(p) == D for p in sys.path) or True)

# detailContent 报告页
dd = sp.detailContent([os.path.join(D, "good.py")])
v = dd["list"][0]
chk("详情页出报告", "协议契约" in v["vod_content"] and "依赖声明" in v["vod_content"])

# 空目录
sp2 = t.Spider(); sp2.init(json.dumps({"dir": "/workspace/pycheck/nonexist", "timeout": 5}))
chk("空目录不崩", sp2._list_files() == [])
chk("空目录 action 提示", "无 py" in sp2._start_batch())

print("\n==== %s ====" % ("ALL PASS" if not NG else "NG: " + ", ".join(NG)))
