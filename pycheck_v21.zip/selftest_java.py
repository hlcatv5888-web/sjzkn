"""端到端：在真 JVM 桩上跑 testpy2 弹窗链路（反射/构建/post 异步/flush 时序/复制回调/降级）"""
import sys, os, json, importlib.util
H = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(H, "sb2")); sys.path.insert(0, H)
import javastub
javastub.install()
AT = javastub.jclass("android.app.ActivityThread")
Act = javastub.jclass("android.app.Activity")
AD = javastub.jclass("android.app.AlertDialog")
TV = javastub.jclass("android.widget.TextView")
LL = javastub.jclass("android.widget.LinearLayout")


s = importlib.util.spec_from_file_location("t2", os.path.join(H, "testpy2.py"))
m = importlib.util.module_from_spec(s); sys.modules["t2"] = m; s.loader.exec_module(m)
sp = m.Spider(); sp.init(json.dumps({"dir": os.path.join(H, "sb2"), "timeout": 5}))

NG = []
def chk(n, c, x=""):
    print(("  OK  " if c else "  NG  ") + n + ("  " + str(x) if x else ""))
    if not c: NG.append(n)

def new_act():
    at = AT(); AT.install(at)
    a = Act()
    at.mActivities.put("t1", AT.ActivityClientRecord(Act(), True))
    at.mActivities.put("t2", AT.ActivityClientRecord(a, False))
    return a

def find(v, cls):
    if isinstance(v, cls): return v
    for c in (getattr(v, "children", None) or []):
        r = find(c, cls)
        if r is not None: return r
    return None

def tvtext():
    tv = find(AD.Builder.last.view, TV)
    return str(tv.getText()) if tv is not None else None

chk("_HAS_JAVA 生效", m._HAS_JAVA is True)
a = new_act()
chk("_activity 跳过 paused 选中前台", sp._activity() == a)

d = sp._live_dialog("测活日志", "首帧文本")
chk("返回 _UiDialog", isinstance(d, m._UiDialog))
chk("post 异步：未 pump 前没弹窗", AD.Builder.last is None)
n = javastub.pump(a)
chk("UI 线程跑起来 ≥2（构建+复制监听）", n >= 1, "ran=%d" % n)
chk("弹窗已 show", AD.Builder.last is not None and AD.Builder.last.shown is True)
chk("标题正确", str(AD.Builder.last.title) == "测活日志")
chk("setView 挂的是 LinearLayout", isinstance(AD.Builder.last.view, LL))
chk("布局竖向", AD.Builder.last.view.orientation == LL.VERTICAL)
chk("内边距 36/20/36/20", tuple(AD.Builder.last.view.pad) == (36, 20, 36, 20))
chk("ScrollView 里放了 TextView", find(AD.Builder.last.view, TV) is not None)
tv = find(AD.Builder.last.view, TV)
chk("字号 13", abs(tv.size - 13.0) < 0.01)
chk("长按可选中", tv.selectable is True)
chk("首帧文本已写入", tvtext() == "首帧文本", tvtext())
chk("复制按钮监听已挂", AD.Builder.last.neutral is not None)
chk("关闭按钮 None 不炸", AD.Builder.last.negative is None)

a2 = new_act()
d2 = sp._live_dialog("T", "初始")
d2.update("进度 3/8")
chk("pump 前 update 不崩（不丢异常）", True)
javastub.pump(a2)
chk("缓存的首批进度已补写", (tvtext() or "").endswith("进度 3/8"), tvtext())

before = a2.getWindow().getDecorView().postCount
d2.update("进度 4/8"); d2.update("进度 5/8")
javastub.pump(a2)
chk("连续 update 取最后一条", (tvtext() or "").endswith("进度 5/8"), tvtext())
chk("每次 update 都切 UI 线程", a2.getWindow().getDecorView().postCount == before + 2,
    "post=%d" % a2.getWindow().getDecorView().postCount)

d2.finish("结束", "完整日志正文XYZ")
javastub.pump(a2)
chk("finish 写入全文", (tvtext() or "").endswith("完整日志正文XYZ"))

try:
    AD.Builder.last.neutral.onClick(None, -1)
    ok = True; err = ""
except Exception as e:
    ok = False; err = type(e).__name__ + ":" + str(e)[:90]
chk("复制按钮回调（含 getText+剪贴板）不抛异常", ok, err)

saved = m._HAS_JAVA; m._HAS_JAVA = False
d3 = sp._live_dialog("x", "y"); m._HAS_JAVA = saved
chk("无 java 降级 _NoDialog", isinstance(d3, m._NoDialog))
d3.update("a"); d3.flush(); d3.finish("t", "b")
chk("_NoDialog 三方法齐活不崩", True)

at3 = AT(); AT.install(at3); at3.mActivities.put("z", AT.ActivityClientRecord(Act(), True))
chk("取不到前台 Activity 时降级", isinstance(sp._live_dialog("x", "y"), m._NoDialog))

print("\n==== %s ====" % ("ALL PASS" if not NG else "NG: " + ", ".join(NG)))
