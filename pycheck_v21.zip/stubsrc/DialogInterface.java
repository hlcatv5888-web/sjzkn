package android.content;
public class DialogInterface {
    public interface OnClickListener { void onClick(DialogInterface d, int which); }
}
