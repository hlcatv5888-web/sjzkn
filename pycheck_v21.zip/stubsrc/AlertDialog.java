package android.app;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
public class AlertDialog {
    public CharSequence title; public View view;
    public Object neutral, negative;   // 真实是 OnClickListener，桩放宽为 Object
    public boolean shown = false;
    public static class Builder {
        public CharSequence title; public View view;
        public Object neutral, negative;
        public Builder(Context c) {}
        public Builder setTitle(CharSequence t) { title = t; return this; }
        public Builder setView(View v) { view = v; return this; }
        public Builder setNeutralButton(CharSequence t, Object l) { neutral = l; return this; }
        public Builder setNegativeButton(CharSequence t, Object l) { negative = l; return this; }
        public AlertDialog show() {
            AlertDialog d = new AlertDialog();
            d.title = title; d.view = view; d.neutral = neutral; d.negative = negative; d.shown = true;
            last = d; return d;
        }
        public static AlertDialog last;
    }
}
