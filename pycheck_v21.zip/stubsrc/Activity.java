package android.app;
import android.content.Context;
import android.view.Window;
public class Activity extends Context {
    public final Window window = new Window();
    public Window getWindow() { return window; }
}
