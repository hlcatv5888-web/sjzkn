package android.widget;
import android.content.Context;
import android.view.View;
public class TextView extends View {
    public CharSequence text = "";
    public float size = 0f;
    public boolean selectable = false;
    public TextView() {}
    public TextView(Context c) {}
    public void setText(CharSequence t) { text = t; }
    public CharSequence getText() { return text; }
    public void setTextSize(float s) { size = s; }
    public void setTextIsSelectable(boolean b) { selectable = b; }
}
