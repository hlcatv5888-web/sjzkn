package android.view;
public class Window {
    public final View decorView = new View();
    public View getDecorView() { return decorView; }
}
