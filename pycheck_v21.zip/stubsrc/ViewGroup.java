package android.view;
import java.util.ArrayList;
import java.util.List;
public class ViewGroup extends View {
    public final List<View> children = new ArrayList<View>();
    public static class LayoutParams {
        public int width, height;
        public LayoutParams(int w, int h) { width=w; height=h; }
    }
    public ViewGroup addView(View v) { return addView(v, null); }
    public ViewGroup addView(View v, LayoutParams p) { if (v != null) children.add(v); return this; }
}
