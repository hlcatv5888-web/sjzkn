package android.content;
public class Context {
    public Object getSystemService(String name) { return new Object(); }
}
