package android.app;
import java.util.HashMap;
import java.util.Map;
public class ActivityThread {
    public static class ActivityClientRecord {
        public boolean paused;
        public Activity activity;
        public ActivityClientRecord(Activity a, boolean p) { activity = a; paused = p; }
    }
    public final Map<Object, ActivityClientRecord> mActivities = new HashMap<Object, ActivityClientRecord>();
    private static ActivityThread current;
    public static ActivityThread currentActivityThread() { return current; }
    public static void install(ActivityThread t) { current = t; }
}
