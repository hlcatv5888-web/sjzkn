// 独立驱动：验证 testpy2 里 _activity() 的反射写法在真 JVM 上成立
import android.app.Activity;
import android.app.ActivityThread;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Driver {
    static Object reflectFind() throws Exception {
        Class<?> JClass = Class.forName("java.lang.Class");
        Class<?> AT = JClass.forName("android.app.ActivityThread");
        Method m = AT.getMethod("currentActivityThread");
        Object cur = m.invoke(null);
        Field f = AT.getDeclaredField("mActivities");
        f.setAccessible(true);
        for (Object r : ((java.util.Map<?, ?>) f.get(cur)).values().toArray()) {
            Class<?> rc = r.getClass();
            Field pf = rc.getDeclaredField("paused");
            pf.setAccessible(true);
            if (!pf.getBoolean(r)) {
                Field af = rc.getDeclaredField("activity");
                af.setAccessible(true);
                return af.get(r);
            }
        }
        return null;
    }
    public static void main(String[] a) throws Exception {
        ActivityThread at = new ActivityThread();
        ActivityThread.install(at);
        Activity pausedAct = new Activity(), liveAct = new Activity();
        at.mActivities.put("token-paused", new ActivityThread.ActivityClientRecord(pausedAct, true));
        at.mActivities.put("token-live", new ActivityThread.ActivityClientRecord(liveAct, false));
        Object got = reflectFind();
        System.out.println("picked_live=" + (got == liveAct));
        System.out.println("picked_paused=" + (got == pausedAct));
        // 全 paused 时应返回 null
        at.mActivities.put("token-live", new ActivityThread.ActivityClientRecord(liveAct, true));
        System.out.println("all_paused_null=" + (reflectFind() == null));
    }
}
