package android.widget;
import android.content.Context;
public class Toast {
    public CharSequence msg; public int dur; public boolean shown = false;
    public static Toast makeText(Context c, CharSequence m, int dur) {
        Toast t = new Toast(); t.msg = m; t.dur = dur; return t;
    }
    public void show() { shown = true; }
}
