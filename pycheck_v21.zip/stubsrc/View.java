package android.view;
import java.util.ArrayList;
import java.util.List;
public class View {
    public int padL, padT, padR, padB;
    public final List<Runnable> pending = new ArrayList<Runnable>();
    public int postCount = 0;
    public boolean post(Runnable r) { postCount++; pending.add(r); return true; }
    public void setPadding(int l, int t, int r, int b) { padL=l; padT=t; padR=r; padB=b; }
    /** 模拟 UI 线程：把积压的任务按序跑掉，返回执行条数 */
    public int drain() { int n = 0; while (!pending.isEmpty()) { pending.remove(0).run(); n++; } return n; }
}
