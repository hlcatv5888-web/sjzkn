package android.widget;
import android.content.Context;
import android.view.ViewGroup;
public class LinearLayout extends ViewGroup {
    public static final int HORIZONTAL = 0, VERTICAL = 1;
    public int orientation = -1;
    public static class LayoutParams extends ViewGroup.LayoutParams {
        public LayoutParams(int w, int h) { super(w, h); }
    }
    public LinearLayout() {}
    public LinearLayout(Context c) {}
    public void setOrientation(int o) { orientation = o; }
}
