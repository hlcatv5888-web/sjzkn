# Py爬虫测活 testpy3.py — 交付包

## 你要用的（手机里只放这一个）
`testpy3.py` — TVBox/FongMi type=3 爬虫，批量检测 `/storage/emulated/0/TV/py` 下所有源

TVBox 加站点：
- type = 3
- api = `https://cdn.jsdmirror.com/gh/hahaha2500/sjzkn@main/testpy3.py`
- ext = `{"dir":"/storage/emulated/0/TV/py","timeout":20,"workers":2}`

进源 → 点「测活」条目 → 弹窗跑日志 → 「复制全文」/ 长按选中
报告自动写到 `目录/pycheck_report.txt`

ext 可选参数：
- `dir` 要测的目录（默认 `/storage/emulated/0/TV/py`）
- `timeout` 单个源整体预算秒（默认 20）
- `workers` 并发数 1~6（默认 2）
- `recursive` true 递归子目录
- `fresh` 0 = 看缓存结果不再重测（默认 1 每次重测）

## 状态含义
- ✅ ok：结构正常 + 分类有数据 + 契约完整
- ⚠️ warn：结构正常但可疑（无数据 / 网络抖 / 契约缺项 / 首页无分类）
- ❌ fail：代码坏了（语法错、没爬虫类、超时、非网络异常）

## 免装依赖
`getDependence()` 返回 `[]`，手机上不需要装 requests 等任何东西。

## 开发者自测（我在电脑上跑的，可复现）
环境：Python 3.12 + `pip install --break-system-packages jpype1` + JDK17
1. `python3 -m py_compile testpy3.py`
2. `python3 testpy2_selftest.py` → 核心 18 项（需同级 `base/spider.py` 桩与样本目录）
3. `javac -d out stubsrc/*.java && java -cp out Driver` → 真 JVM 验反射
4. `python3 selftest_java.py` → 弹窗链路 25 项（需先装 javastub.py）

## 目录说明
- `testpy3.py` 交付本体
- `testpy2.py` 上一版（弹窗首帧有 bug，别用，留档对比）
- `testpy2_selftest.py` 核心自测
- `selftest_java.py` + `javastub.py` + `stubsrc/` 弹窗链路自测与 Android 桩类
